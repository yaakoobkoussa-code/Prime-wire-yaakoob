let allKeys = [];
let allNodes = [];
let allFeatures = [];
let currentFilter = 'all';

const $ = id => document.getElementById(id);
function showToast(message) {
  const toast = $('toast');
  if (!toast) return;
  toast.textContent = message;
  toast.style.display = 'flex';
  setTimeout(() => { toast.style.display = 'none'; }, 2600);
}
async function api(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}
function formatExpiry(iso) {
  if (!iso) return 'Lifetime';
  const diff = new Date(iso).getTime() - Date.now();
  if (diff <= 0) return '<span style="color:#f87171">Expired</span>';
  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  return days > 365 ? 'Lifetime' : days ? `${days}d ${hours}h left` : `${hours}h left`;
}
async function loadOverview() {
  const data = await api('/api/admin/overview');
  $('stat-total-keys').textContent = data.totalKeys;
  $('stat-active-keys').textContent = data.activeKeys;
  $('stat-unbound-keys').textContent = data.unboundKeys;
  $('stat-connected-users').textContent = `${data.totalUsers} users`;
  $('stat-maintenance-status').textContent = data.maintenance?.enabled ? 'ON (Paused)' : 'OFF (Normal)';
  $('maint-toggle').checked = !!data.maintenance?.enabled;
  $('maint-allowed').value = (data.maintenance?.allowed_logins || []).join(', ');
  $('maint-msg').value = data.maintenance?.message || '';
}
async function loadKeys() { allKeys = (await api('/api/admin/keys')).keys || []; renderKeys(); }
function renderKeys() {
  const search = ($('key-search').value || '').toLowerCase();
  const rows = allKeys.filter(k => {
    const expired = new Date(k.expires_at).getTime() <= Date.now();
    const match = !search || [k.key, k.bound_hwid, k.note].some(v => String(v || '').toLowerCase().includes(search));
    if (!match) return false;
    if (currentFilter === 'active') return k.status === 'active' && !expired;
    if (currentFilter === 'unbound') return !k.bound_hwid && k.status === 'active';
    if (currentFilter === 'expired') return expired;
    if (currentFilter === 'revoked') return k.status === 'revoked';
    return true;
  });
  $('keys-tbody').innerHTML = rows.length ? rows.map(k => {
    const expired = new Date(k.expires_at).getTime() <= Date.now();
    const status = k.status === 'revoked' ? ['badge-revoked','Revoked'] : expired ? ['badge-expired','Expired'] : !k.bound_hwid ? ['badge-unbound','Unbound'] : ['badge-active','Active'];
    return `<tr><td><div style="display:flex;align-items:center;gap:6px"><code>${escapeHtml(k.key)}</code><button class="btn-action" data-action="copy" data-key="${escapeHtml(k.key)}">Copy</button></div></td><td><span class="badge ${status[0]}">${status[1]}</span></td><td>${escapeHtml(k.device_model || 'Ready for binding')}</td><td>${formatExpiry(k.expires_at)}</td><td>${escapeHtml(k.note || '—')}</td><td><div class="action-group"><button class="btn-action" data-action="unbind" data-key="${escapeHtml(k.key)}">Unbind</button><button class="btn-action" data-action="extend" data-key="${escapeHtml(k.key)}">+30d</button><button class="btn-action" data-action="toggle" data-key="${escapeHtml(k.key)}">${k.status === 'revoked' ? 'Activate' : 'Revoke'}</button><button class="btn-action btn-admin-danger" data-action="delete" data-key="${escapeHtml(k.key)}">Delete</button></div></td></tr>`;
  }).join('') : '<tr><td colspan="6" style="text-align:center;padding:28px;color:#888">No license keys found.</td></tr>';
}
function nodeForm(n = {}) {
  return `<div class="panel-card node-row" data-node-id="${escapeHtml(n.id || '')}"><div style="display:grid;grid-template-columns:80px 1fr 1fr;gap:10px;align-items:end"><div class="form-group"><label class="form-label">Flag</label><input class="form-control node-flag" value="${escapeHtml(n.flag || '🌐')}"></div><div class="form-group"><label class="form-label">Name</label><input class="form-control node-name" value="${escapeHtml(n.name || '')}"></div><div class="form-group"><label class="form-label">Host</label><input class="form-control node-host" value="${escapeHtml(n.host || '')}"></div><div class="form-group"><label class="form-label">Port</label><input class="form-control node-port" type="number" value="${n.port || 443}"></div><div class="form-group" style="grid-column:span 2"><label class="form-label">Subscription URL — use {key} and {node}</label><input class="form-control node-url" value="${escapeHtml(n.subscription_url || '')}"></div></div></div>`;
}
function renderNodes() { $('nodes-editor').innerHTML = allNodes.map(nodeForm).join(''); }
function renderFeatures() { $('features-editor').innerHTML = allFeatures.map(f => `<div class="panel-card feature-row" data-feature-id="${escapeHtml(f.id)}"><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px"><div class="form-group"><label class="form-label">Feature ID</label><input class="form-control feature-id" value="${escapeHtml(f.id)}" readonly></div><div class="form-group"><label class="form-label">Name</label><input class="form-control feature-name" value="${escapeHtml(f.name)}"></div><div class="form-group"><label class="form-label">Description</label><input class="form-control feature-description" value="${escapeHtml(f.description)}"></div><div class="form-group"><label class="form-label">Open / Subscription URL</label><input class="form-control feature-url" value="${escapeHtml(f.open_url || '')}"></div></div></div>`).join(''); }
async function loadSettings() { const data = await api('/api/settings'); allNodes = data.nodes || []; allFeatures = data.features || []; renderNodes(); renderFeatures(); }
function copyText(text) { navigator.clipboard?.writeText(text); showToast('Copied'); }

document.addEventListener('DOMContentLoaded', async () => {
  try { await Promise.all([loadOverview(), loadKeys(), loadSettings()]); } catch (e) { showToast(e.message); }
  $('key-search')?.addEventListener('input', renderKeys);
  document.querySelectorAll('.filter-tab').forEach(tab => tab.addEventListener('click', () => { currentFilter = tab.dataset.filter || 'all'; renderKeys(); }));
  $('refresh-keys-btn')?.addEventListener('click', () => Promise.all([loadOverview(), loadKeys(), loadSettings()]));
  $('add-node-btn')?.addEventListener('click', () => { allNodes.push({ id: `node-${Date.now()}`, name: 'New Server', flag: '🌐', port: 443, status: 'online' }); renderNodes(); });
  $('save-nodes-btn')?.addEventListener('click', async () => { try { const nodes = [...document.querySelectorAll('.node-row')].map(row => ({ id: row.dataset.nodeId, flag: row.querySelector('.node-flag').value, name: row.querySelector('.node-name').value, host: row.querySelector('.node-host').value, port: row.querySelector('.node-port').value, subscription_url: row.querySelector('.node-url').value })); await api('/api/admin/nodes', {method:'PUT', headers:{'Content-Type':'application/json'}, body:JSON.stringify({nodes})}); showToast('Servers saved'); await loadSettings(); } catch(e) { showToast(e.message); } });
  $('save-features-btn')?.addEventListener('click', async () => { try { const features = [...document.querySelectorAll('.feature-row')].map(row => ({ id: row.dataset.featureId, name: row.querySelector('.feature-name').value, description: row.querySelector('.feature-description').value, open_url: row.querySelector('.feature-url').value })); await api('/api/admin/features', {method:'PUT', headers:{'Content-Type':'application/json'}, body:JSON.stringify({features})}); showToast('Features saved'); await loadSettings(); } catch(e) { showToast(e.message); } });
  $('gen-key-form')?.addEventListener('submit', async e => { e.preventDefault(); try { const data = await api('/api/admin/keys/generate', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({days:$('gen-duration').value,count:$('gen-count').value,note:$('gen-note').value})}); $('gen-result-key').textContent = data.keys?.[0]?.key || ''; $('gen-result').style.display = 'block'; showToast('Keys generated'); await Promise.all([loadKeys(),loadOverview()]); } catch(err) { showToast(err.message); } });
  $('maint-form')?.addEventListener('submit', async e => { e.preventDefault(); try { await api('/api/admin/maintenance',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled:$('maint-toggle').checked,allowed_logins:$('maint-allowed').value,message:$('maint-msg').value})}); showToast('Settings saved'); } catch(err) { showToast(err.message); } });
  $('keys-tbody')?.addEventListener('click', async e => { const btn=e.target.closest('[data-action]'); if(!btn) return; const key=encodeURIComponent(btn.dataset.key); try { if(btn.dataset.action==='delete' && !confirm('Delete this key?')) return; const action=btn.dataset.action; if(action==='copy') { copyText(btn.dataset.key); showToast('Key copied'); return; } if(action==='delete') await api(`/api/admin/keys/${key}`,{method:'DELETE'}); else if(action==='unbind') await api(`/api/admin/keys/${key}/unbind`,{method:'POST'}); else if(action==='extend') await api(`/api/admin/keys/${key}/extend`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({days:30})}); else await api(`/api/admin/keys/${key}/toggle-status`,{method:'POST'}); await Promise.all([loadKeys(),loadOverview()]); showToast('Updated'); } catch(err) { showToast(err.message); } });
});
